import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Calendar, MapPin, Mail, Phone, Settings, Download, Sparkles, Check } from 'lucide-react';
import { BUSINESS_CONFIG } from '../config/business';

interface HeaderProps {
  onOpenBooking: (serviceId?: string) => void;
  onOpenConfig?: () => void;
  onOpenDownload?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenBooking, onOpenConfig, onOpenDownload }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About Us', path: '/about' },
    { name: 'Services & Pricing', path: '/services' },
    { name: 'Sanctuary Gallery', path: '/gallery' },
    { name: 'Contact & Map', path: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  // Direct, reliable project zip download handler
  const handleDownloadZipDirect = () => {
    try {
      const link = document.createElement('a');
      link.href = `/${BUSINESS_CONFIG.zipFileName}`;
      link.download = BUSINESS_CONFIG.zipFileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3500);
    } catch {
      if (onOpenDownload) {
        onOpenDownload();
      }
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#E3DACD] shadow-xs">
      
      {/* 1. Clean, Professional Top Utility & Project Download Section */}
      <div className="bg-[#201C17] text-[#ECE4D8] text-xs py-2 px-4 md:px-8 border-b border-[#332D26]">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          
          {/* Location & Sanctuary Timing */}
          <div className="flex items-center gap-4 text-[#C5BBAF]">
            <span className="flex items-center gap-1.5 text-[#F5F0E8]">
              <MapPin className="w-3.5 h-3.5 text-[#7A9988] shrink-0" />
              <span>{BUSINESS_CONFIG.city}, {BUSINESS_CONFIG.state}</span>
            </span>
            <span className="hidden sm:inline text-[#8C8275]">·</span>
            <span className="hidden sm:inline text-[#ECE4D8]/90">Mon–Sun 9:00 AM – 9:00 PM</span>
          </div>

          {/* Right Action Cluster: Direct Download ZIP Button & Contact */}
          <div className="flex items-center gap-3">
            <a 
              href={`mailto:${BUSINESS_CONFIG.email}`}
              className="hidden lg:flex items-center gap-1.5 hover:text-white transition-colors text-[#ECE4D8]"
            >
              <Mail className="w-3.5 h-3.5 text-[#7A9988]" />
              <span className="underline decoration-[#7A9988] underline-offset-2">{BUSINESS_CONFIG.email}</span>
            </a>

            {BUSINESS_CONFIG.isPhoneConfigured && BUSINESS_CONFIG.phone && (
              <a 
                href={`tel:${BUSINESS_CONFIG.phone}`}
                className="hidden md:flex items-center gap-1.5 hover:text-white transition-colors text-[#ECE4D8]"
              >
                <Phone className="w-3.5 h-3.5 text-[#7A9988]" />
                <span>{BUSINESS_CONFIG.phone}</span>
              </a>
            )}

            {/* Clearly Visible & Functional Download ZIP Button in Top Bar */}
            <button
              onClick={handleDownloadZipDirect}
              title="Download the complete AuraNest Wellness project files as a ZIP package"
              className="flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium bg-[#446353] hover:bg-[#365143] text-white transition-all shadow-xs cursor-pointer border border-[#7A9988]/40"
            >
              {downloadSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#E7EFEA]" />
                  <span>ZIP Downloaded!</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5 text-[#E7EFEA]" />
                  <span>Download ZIP</span>
                </>
              )}
            </button>

            {onOpenConfig && (
              <button
                onClick={onOpenConfig}
                title="Configure Business & Map settings"
                className="flex items-center gap-1 px-2.5 py-1 rounded text-xs bg-[#2E2822] text-[#C5BBAF] hover:text-white hover:bg-[#446353] transition-colors cursor-pointer border border-[#3E362E]"
              >
                <Settings className="w-3 h-3 text-[#7A9988]" />
                <span className="hidden sm:inline">Settings</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 2. Main Navigation Bar: Brand Identity, Nav Links & Action Buttons */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6 h-20">
          
          {/* Brand Identity: AuraNest Wellness */}
          <Link 
            to="/" 
            className="flex items-center gap-3.5 group whitespace-nowrap shrink-0"
          >
            <div className="w-11 h-11 rounded-full bg-[#FAF7F2] border border-[#7A9988]/50 flex items-center justify-center text-[#28231D] group-hover:bg-[#E7EFEA] transition-colors shadow-xs">
              <span className="font-serif text-2xl font-bold tracking-tight text-[#446353]">A</span>
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-2xl sm:text-[26px] font-semibold tracking-tight text-[#28231D] leading-tight group-hover:text-[#446353] transition-colors">
                {BUSINESS_CONFIG.brandName}
              </span>
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#8C8275] font-sans font-medium">
                Sanctuary · Bhopal
              </span>
            </div>
          </Link>

          {/* Clean Navigation Links with Sage Accents */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#28231D]">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
                  isActive(link.path)
                    ? 'text-[#446353] font-semibold border-b-2 border-[#446353]'
                    : 'text-[#28231D] hover:text-[#446353]'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Primary Action Buttons: Download ZIP + Book Appointment */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            {/* Download ZIP Secondary Button in Navbar */}
            <button
              onClick={handleDownloadZipDirect}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold uppercase tracking-wider text-[#446353] bg-[#E7EFEA] hover:bg-[#D5E4DC] border border-[#7A9988]/40 rounded-sm transition-colors shadow-xs whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download ZIP</span>
            </button>

            {/* Book Appointment CTA */}
            <button
              onClick={() => onOpenBooking()}
              className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#446353] hover:bg-[#365143] rounded-sm transition-all shadow-xs hover:shadow-sm whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Book Appointment</span>
            </button>
          </div>

          {/* Mobile hamburger */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle navigation menu"
              className="p-2 text-[#28231D] hover:text-[#446353] rounded-md hover:bg-[#F3EFE6] transition-colors"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#E3DACD] bg-[#FAF7F2] px-6 py-6 shadow-xl animate-in slide-in-from-top-2 duration-200">
          <nav className="flex flex-col gap-4 text-base font-medium text-[#28231D]">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`py-2 px-3 rounded-md transition-colors ${
                  isActive(link.path)
                    ? 'bg-[#E7EFEA] text-[#446353] font-semibold'
                    : 'hover:bg-[#F3EFE6] text-[#28231D]'
                }`}
              >
                {link.name}
              </Link>
            ))}

            <div className="pt-4 border-t border-[#E3DACD] flex flex-col gap-3">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  handleDownloadZipDirect();
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold uppercase tracking-wider text-[#446353] bg-[#E7EFEA] hover:bg-[#D5E4DC] border border-[#7A9988]/40 rounded-sm transition-colors shadow-xs"
              >
                <Download className="w-4 h-4" />
                <span>Download Project ZIP</span>
              </button>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBooking();
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold uppercase tracking-wider text-white bg-[#446353] hover:bg-[#365143] rounded-sm transition-colors shadow-xs"
              >
                <Calendar className="w-4 h-4" />
                <span>Book Appointment</span>
              </button>

              <div className="text-xs text-[#685F53] flex flex-col gap-1 pt-2">
                <span>📍 {BUSINESS_CONFIG.city}, {BUSINESS_CONFIG.state}</span>
                <span>✉️ {BUSINESS_CONFIG.email}</span>
                {BUSINESS_CONFIG.phone && <span>📞 {BUSINESS_CONFIG.phone}</span>}
              </div>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
